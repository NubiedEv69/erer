export { default as useCopyToClipboard } from 'react-use/lib/useCopyToClipboard';
